package br.com.lirio.appredis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppRedisApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppRedisApplication.class, args);
	}

}
